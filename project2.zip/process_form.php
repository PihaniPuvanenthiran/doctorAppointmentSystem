<?php

if($_SERVER["REQUEST_METHOD"]=="POST"){
    
//declare variables to FORM1 details.


    $patientId= ($_POST['patient_Id']);
    $patientName=($_POST['patient_name']);
    $mobileNum=($_POST['mobile_number']);
    $NIC=($_POST['NIC']);
    $doctorId=($_POST['doctor_Id']);
    $doctorName=($_POST['doctor_name']);
    $specialist=($_POST['specialist']);
    $appointmentId=($_POST["appointment_Id"]);
    $appointmentDate=($_POST["appointment_date"]);
    $appointmentReason=($_POST["appointment_reason"]);

}
else{
    echo "<p>Form submission failed. Please try again.</p> ";
    exit(); // Exit early if the form wasn't submitted
}

/*if (!empty($patientId)||!empty($patientName)|| !empty($mobileNum)!empty($NIC)|| !empty($doctorId)|| !empty($doctorName)|| !empty($specialist)|| !empty($appointmentId)|| !empty($appointmentDate)) {

   
}*/

// Connect the database 
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "pro2"; //database name

//create a connection
$conn = new mysqli($servername, $username, $password, $dbname);

//check connection
if($conn->connect_error){
    die("Connection failed !!!" .$conn->connect_error);

}

// Prepare and execute an SQL INSERT statement

//.....patient_details TABLE.......
$p_details=$conn->prepare("INSERT INTO p(Patient_Id, Patient_Name, Mobile_Number, NIC_Number)VALUES(?, ?, ?, ?)");

$p_details->bind_param("ssis", $patientId, $patientName, $mobileNum, $NIC);


//.....doctor_details TABLE.......

$d_details=$conn->prepare("INSERT INTO d(  Doctor_Id, Doctor_Name, Specialist)VALUES(?, ?, ?)");

$d_details->bind_param("sss", $doctorId, $doctorName, $specialist);


//.....appointment_details TABLE.......
$a_details=$conn->prepare("INSERT INTO a(Appointment_Id, Patient_Id, Doctor_Id, Appointment_Date, Appointment_Reason)VALUES(?, ?, ?, ?, ?)");

$a_details->bind_param("sssss", $appointmentId, $patientId, $doctorId, $appointmentDate, $appointmentReason);



// Execute the statements
$p_details_success = $p_details->execute();
$d_details_success = $d_details->execute();
$a_details_success = $a_details->execute();

if ($p_details_success && $d_details_success && $a_details_success) {
    echo "Form data submitted successfully.";
}
 else {
    echo "Error: " . $conn->error;
}

// Close the statements and the database connection
$p_details->close();
$d_details->close();
$a_details->close();
$conn->close();

?>
